# Crime Data Analysis

This folder contains:
- crime_database.db: The main database for crime and demographics data
- crime_data_queries.sql: Sample SQL queries for analysis

To use DuckDB with this database, you'll need to first install DuckDB.
